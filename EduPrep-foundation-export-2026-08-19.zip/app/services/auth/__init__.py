"""Supabase authentication service."""
