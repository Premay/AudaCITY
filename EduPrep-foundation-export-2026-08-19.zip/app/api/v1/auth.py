from typing import Annotated, Any

from fastapi import APIRouter, Depends, status

from app.dependencies import get_access_token, get_auth_service
from app.schemas.auth import EmailRequest, LoginRequest, MessageResponse, RegisterRequest
from app.services.auth.supabase import SupabaseAuthService

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(
    request: RegisterRequest,
    service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
) -> dict[str, Any]:
    """Create a Supabase Auth account; a database trigger creates the profile."""
    metadata = {
        key: value
        for key, value in {
            "full_name": request.full_name,
            "class_level": request.class_level,
        }.items()
        if value is not None
    }
    return await service.register(
        {"email": request.email, "password": request.password, "data": metadata}
    )


@router.post("/login")
async def login(
    request: LoginRequest,
    service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
) -> dict[str, Any]:
    """Exchange an email and password for a Supabase session."""
    return await service.login(request.email, request.password)


@router.post("/logout", response_model=MessageResponse)
async def logout(
    access_token: Annotated[str, Depends(get_access_token)],
    service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
) -> MessageResponse:
    await service.logout(access_token)
    return MessageResponse(message="You have been logged out.")


@router.post("/reset-password", response_model=MessageResponse)
async def reset_password(
    request: EmailRequest,
    service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
) -> MessageResponse:
    """Request a reset email without revealing whether an account exists."""
    await service.send_password_reset(request.email)
    return MessageResponse(
        message="If an account exists for this email, password reset instructions have been sent."
    )
