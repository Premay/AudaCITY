from typing import Annotated, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import get_access_token, get_auth_service, get_catalog_service
from app.services.auth.supabase import SupabaseAuthService
from app.services.catalog import CatalogService

router = APIRouter(tags=["catalogue"])


async def ensure_authenticated(
    service: SupabaseAuthService, access_token: str
) -> None:
    """Validate the bearer token before requesting reference data."""
    await service.get_user(access_token)


@router.get("/exams")
async def list_exams(
    access_token: Annotated[str, Depends(get_access_token)],
    auth_service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
    catalog_service: Annotated[CatalogService, Depends(get_catalog_service)],
) -> list[dict[str, Any]]:
    await ensure_authenticated(auth_service, access_token)
    return await catalog_service.fetch("exams", "select=id,name,code,description&order=name", access_token)


@router.get("/exams/{exam_id}")
async def get_exam(
    exam_id: UUID,
    access_token: Annotated[str, Depends(get_access_token)],
    auth_service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
    catalog_service: Annotated[CatalogService, Depends(get_catalog_service)],
) -> dict[str, Any]:
    await ensure_authenticated(auth_service, access_token)
    records = await catalog_service.fetch(
        "exams", f"id=eq.{exam_id}&select=id,name,code,description", access_token
    )
    if not records:
        raise HTTPException(status_code=404, detail="Exam was not found.")
    return records[0]


@router.get("/subjects")
async def list_subjects(
    access_token: Annotated[str, Depends(get_access_token)],
    auth_service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
    catalog_service: Annotated[CatalogService, Depends(get_catalog_service)],
) -> list[dict[str, Any]]:
    await ensure_authenticated(auth_service, access_token)
    return await catalog_service.fetch("subjects", "select=id,name,code&order=name", access_token)


@router.get("/subjects/{subject_id}")
async def get_subject(
    subject_id: UUID,
    access_token: Annotated[str, Depends(get_access_token)],
    auth_service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
    catalog_service: Annotated[CatalogService, Depends(get_catalog_service)],
) -> dict[str, Any]:
    await ensure_authenticated(auth_service, access_token)
    records = await catalog_service.fetch(
        "subjects", f"id=eq.{subject_id}&select=id,name,code", access_token
    )
    if not records:
        raise HTTPException(status_code=404, detail="Subject was not found.")
    return records[0]


@router.get("/subjects/{subject_id}/topics")
async def list_topics(
    subject_id: UUID,
    access_token: Annotated[str, Depends(get_access_token)],
    auth_service: Annotated[SupabaseAuthService, Depends(get_auth_service)],
    catalog_service: Annotated[CatalogService, Depends(get_catalog_service)],
    limit: Annotated[int, Query(ge=1, le=100)] = 50,
) -> list[dict[str, Any]]:
    await ensure_authenticated(auth_service, access_token)
    return await catalog_service.fetch(
        "topics",
        f"subject_id=eq.{subject_id}&select=id,subject_id,name,description&order=name&limit={limit}",
        access_token,
    )
